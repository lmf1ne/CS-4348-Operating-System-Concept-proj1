
#ifndef SRC_ENCRYPT_H
#define SRC_ENCRYPT_H

char* encryption(char* msg,  char* key);
char* decryption(char* msg,  char* key);

#endif //SRC_ENCRYPT_H
