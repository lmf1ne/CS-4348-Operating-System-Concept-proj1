
#ifndef SRC_LOGGER_H
#define SRC_LOGGER_H

#endif //SRC_LOGGER_H

char* getTimeString();
char* getLogLine(char* action, char* msg);