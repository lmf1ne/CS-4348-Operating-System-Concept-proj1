

#ifndef SRC_MAIN_H
#define SRC_MAIN_H

char* getNextString(char* h[], int size);
void printAllHistory(char* h[], int size);
#endif //SRC_MAIN_H